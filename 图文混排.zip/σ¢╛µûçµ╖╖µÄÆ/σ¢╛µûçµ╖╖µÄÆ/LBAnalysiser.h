//
//  LBAnalysiser.h
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBAnalysiser : NSObject

@property (nonatomic , strong)NSMutableArray <NSDictionary *>*arr;
@property (nonatomic , strong)NSMutableArray *views;
@property (nonatomic , strong)NSMutableAttributedString *attrString;

- (NSAttributedString *)lb_analysisWithText:(NSString *)text;

@end
