
//
//  LBAnalysiser.m
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import "LBAnalysiser.h"
#import <CoreText/CoreText.h>

@interface LBModel:NSObject
@property (nonatomic , assign)CGFloat width;
@property (nonatomic , assign)CGFloat height;
@property (nonatomic , assign)CGFloat ascent;
@property (nonatomic , assign)CGFloat descent;

@end

@implementation LBModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _width = 0;
        _height = 0;
        _ascent = [UIFont systemFontOfSize:20].ascender;
        _descent = -[UIFont systemFontOfSize:20].descender;
    }
    return self;
}

@end;

@implementation LBAnalysiser

- (NSMutableArray<NSDictionary *> *)arr {
    if (!_arr) {
        _arr = [[NSMutableArray alloc]init];
    }
    return _arr;
}

- (NSMutableArray *)views {
    if (!_views) {
        _views = [[NSMutableArray alloc]init];
    }
    return _views;
}

- (NSAttributedString *)lb_analysisWithText:(NSString *)text{
    _attrString = [[NSMutableAttributedString alloc]initWithString:@""];
    NSRegularExpression *ex = [NSRegularExpression regularExpressionWithPattern:@"(.*?)(<[^>]+>|\\Z)" options:NSRegularExpressionCaseInsensitive |NSRegularExpressionDotMatchesLineSeparators error:nil];
   NSArray *chunks = [ex matchesInString:text options: 0 range:NSMakeRange(0, text.length)];
    for (NSTextCheckingResult * chunk in chunks) {
        NSString *string = [text substringWithRange:chunk.range];
        NSArray *parts = [string componentsSeparatedByString:@"<"];
        NSDictionary *attrDic = @{
                                  NSForegroundColorAttributeName : [UIColor redColor],
                                  NSFontAttributeName : [UIFont systemFontOfSize:20]
                                  };
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc]initWithString:parts.firstObject attributes:attrDic];
        [_attrString appendAttributedString:str];

        if (parts.count < 2) {
            continue;
        }
        NSString *tag = parts.lastObject;
        if (![tag hasPrefix:@"img"]) continue ;
        
        NSRegularExpression *imgRegex = [NSRegularExpression regularExpressionWithPattern:@"(?<=src=\")[^\"]+" options:0 error:nil];
        NSArray *imgMacths = [imgRegex matchesInString:tag options:0 range:NSMakeRange(0, tag.length)];
        CGFloat lineHeight = floor([UIFont systemFontOfSize:20].lineHeight) + 1;
        for (NSTextCheckingResult *imgMacth in imgMacths) {
            NSString *fileName = [tag substringWithRange:imgMacth.range];
            LBModel *model = [[LBModel alloc]init];
            if ([fileName isEqualToString:@"switch"]) {
                model.width = 80;
                model.height = 90;
                UIView *greenView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 10)];
                greenView.backgroundColor = [UIColor greenColor];
                [self.views addObject:@{
                                        @"model":model,
                                        @"switch":greenView,
                                        @"location":@(self.attrString.string.length)
                                        }];
            }else {
                UIImage *image = [UIImage imageNamed:fileName];
                CGFloat width = [UIScreen mainScreen].bounds.size.width;
                CGFloat height = width * (image.size.height / image.size.width);
                
                if (height >= [UIScreen mainScreen].bounds.size.height - lineHeight) {
                    height = [UIScreen mainScreen].bounds.size.height - lineHeight;
                    width = height * (image.size.width / image.size.height);
                }
                model.width = width;
                model.height = height;
                [self.arr addObject:@{
                                      @"width": @(width),
                                      @"height": @(height),
                                      @"filename": fileName,
                                      @"location": @(self.attrString.string.length),
                                      @"model": model
                                      }];
            }
            
            //为图片设置CTRunDelegate,delegate决定留给显示内容的空间大小
            CTRunDelegateCallbacks runCallbacks;
            runCallbacks.version = kCTRunDelegateVersion1;
            runCallbacks.dealloc = TYTextRunDelegateDeallocCallback;
            runCallbacks.getAscent = TYTextRunDelegateGetAscentCallback;
            runCallbacks.getDescent = TYTextRunDelegateGetDescentCallback;
            runCallbacks.getWidth = TYTextRunDelegateGetWidthCallback;
            
            CTRunDelegateRef runDelegate = CTRunDelegateCreate(&runCallbacks, (__bridge void *)(model));
            NSMutableAttributedString *imgStr = [[NSMutableAttributedString alloc]initWithString:@" " attributes:@{
                                                                                                                   (__bridge_transfer NSString *)kCTRunDelegateAttributeName : (__bridge id)runDelegate                                                                                                                   }];
            [self.attrString appendAttributedString:imgStr];
            CFRelease(runDelegate);
        }

    }
    return self.attrString;
}
//CTRun的回调，销毁内存的回调
void TYTextRunDelegateDeallocCallback( void* refCon ){

}

//CTRun的回调，获取高度
CGFloat TYTextRunDelegateGetAscentCallback( void *refCon ){
    LBModel *model = (__bridge LBModel *)refCon;
    return model.height - model.descent;
}

CGFloat TYTextRunDelegateGetDescentCallback(void *refCon){
    LBModel *model = (__bridge LBModel *)refCon;
    return model.descent;
    
}

//CTRun的回调，获取宽度
CGFloat TYTextRunDelegateGetWidthCallback(void *refCon){
    LBModel *model = (__bridge LBModel *)refCon;
    return model.width;
}
@end
