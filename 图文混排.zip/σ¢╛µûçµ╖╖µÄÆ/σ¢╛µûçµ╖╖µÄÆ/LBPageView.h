//
//  LBPageView.h
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@interface LBPageView : UIView
@property (nonatomic , strong)NSMutableArray <NSDictionary *> *images;
@property (nonatomic , strong)NSMutableArray <NSDictionary *> *views;
- (instancetype)initWithCTFrame:(CTFrameRef)ctframe andFrame:(CGRect)frame;
@end
