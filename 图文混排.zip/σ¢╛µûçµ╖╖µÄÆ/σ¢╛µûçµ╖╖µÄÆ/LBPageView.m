//
//  LBPageView.m
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import "LBPageView.h"

@interface LBPageView ()

@property (nonatomic , assign)CTFrameRef ctframe;


@end

@implementation LBPageView

- (instancetype)initWithCTFrame:(CTFrameRef)ctframe andFrame:(CGRect)frame;
{
    LBPageView *pageView = [[LBPageView alloc]initWithFrame:frame];
    
    pageView.images = [[NSMutableArray alloc]init];
    pageView.ctframe = ctframe;
    pageView.views = [[NSMutableArray alloc]init];
    pageView.backgroundColor = [UIColor whiteColor];
    return pageView;
}

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextTranslateCTM(context, 0, [UIScreen mainScreen].bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CTFrameDraw(self.ctframe, context);
    for (NSDictionary *dic in self.images) {
        UIImage *image = dic[@"image"];
        CGRect frame = [dic[@"imageframe"] CGRectValue];
        CGContextDrawImage(context, frame, image.CGImage);
    }

    for (NSDictionary *dic in self.views) {
        UIView *view = dic[@"switch"];
        CGAffineTransform transform =  CGAffineTransformScale(CGAffineTransformMakeTranslation(0, self.bounds.size.height), 1.f, -1.f);
        rect = CGRectApplyAffineTransform([dic[@"switchFrame"] CGRectValue], transform);
        view.frame = rect;
        [self addSubview:view];
    }
}
@end
