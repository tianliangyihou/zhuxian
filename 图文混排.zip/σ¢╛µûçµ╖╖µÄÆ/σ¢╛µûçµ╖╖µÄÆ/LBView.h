//
//  LBView.h
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBView : UIScrollView
@property (nonatomic , assign)int imageIndex;
@property (nonatomic , assign)int viewIndex;

- (void)buildFramesWithAttr:(NSAttributedString *)attr andImages:(NSArray *)images andView:(NSArray *)views;

@end
