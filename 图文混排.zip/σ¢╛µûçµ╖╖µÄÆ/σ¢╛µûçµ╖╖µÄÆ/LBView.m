//
//  LBView.m
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import "LBView.h"
#import "LBPageView.h"
#import <CoreText/CoreText.h>
@implementation LBView

- (void)buildFramesWithAttr:(NSAttributedString *)attr andImages:(NSArray *)images andView:(NSArray *)views{
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)attr);
    int textPos = 0;
    int page = 0;
    _imageIndex = 0;
    _viewIndex = 0;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    while (textPos < attr.string.length) {
        UIBezierPath *bPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, screenWidth, screenHeight)];
        if (textPos == 0) {
            [bPath addArcWithCenter:CGPointMake(screenWidth /2.0, screenHeight/2.0) radius:screenWidth /2.0 startAngle:0 endAngle:M_PI * 2 clockwise:YES];
        }

        CGMutablePathRef path = CGPathCreateMutableCopy(bPath.CGPath);
        CTFrameRef frame = CTFramesetterCreateFrame(frameSetter,CFRangeMake(textPos, 0) , path, NULL);
        LBPageView *pageView = [[LBPageView alloc]initWithCTFrame:frame andFrame:CGRectMake(page *screenWidth , 0, screenWidth, screenHeight)];
        if (images.count > _imageIndex) {
            [self attachImagesWithFrame:frame array:images pageView:pageView];
        }
        if (views.count > _viewIndex ) {
            [self attachViewsWithFrame:frame array:views pageView:pageView];
        }
        
        [self addSubview:pageView];
        
        CFRange range =  CTFrameGetVisibleStringRange(frame);
        textPos += range.length;
        page = page + 1;
    }
    self.contentSize = CGSizeMake(page *[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    self.pagingEnabled = YES;
}

- (void)attachImagesWithFrame:(CTFrameRef)frame array:(NSArray <NSDictionary *>*)arr pageView:(LBPageView *)pageView  {
    CFArrayRef ctlines = CTFrameGetLines(frame);
    CGPoint lineOrigins[CFArrayGetCount(ctlines)];
    CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
    NSDictionary *imageDic = arr[_imageIndex];
    int location = [imageDic[@"location"] intValue];
    if (location <0) {
        return;
    }
    for (int i = 0; i <CFArrayGetCount(ctlines);i++) {
        CTLineRef line = CFArrayGetValueAtIndex(ctlines, i);
        NSString *imageName = imageDic[@"filename"];
        UIImage *image = [UIImage imageNamed:imageName];
        CFArrayRef runs = CTLineGetGlyphRuns(line);
        CGPoint origin = lineOrigins[i];
        for (int i = 0; i <CFArrayGetCount(runs);i++) {
            CTRunRef run = CFArrayGetValueAtIndex(runs, i);
            CFRange range = CTRunGetStringRange(run);
            if (range.location > location || range.location + range.length <= location ) {
                continue;
            }
            CGFloat ascent ;
            CGFloat width = (CGFloat)CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &ascent, nil, nil);
            CGFloat offsetX = CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, nil);
            CGRect imageBounds = CGRectMake(origin.x + offsetX, origin.y, width, ascent);
            [pageView.images addObject:@{
                                         @"image" :image,
                                         @"imageframe": [NSValue valueWithCGRect:imageBounds]
                                         }];
            self.imageIndex += 1;
            if (self.imageIndex < arr.count) {
                imageDic = arr[self.imageIndex];
                location = [imageDic[@"location"] intValue];
            }
        }
        
        
    }
    
    
}

- (void)attachViewsWithFrame:(CTFrameRef)frame array:(NSArray <NSDictionary *>*)arr pageView:(LBPageView *)pageView  {
    CFArrayRef ctlines = CTFrameGetLines(frame);
    CGPoint lineOrigins[CFArrayGetCount(ctlines)];
    CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
    NSDictionary *viewDic = arr[_viewIndex];
    int location = [viewDic[@"location"] intValue];
    if (location <0) {
        return;
    }
    for (int i = 0; i <CFArrayGetCount(ctlines);i++) {
        CTLineRef line = CFArrayGetValueAtIndex(ctlines, i);
        CFArrayRef runs = CTLineGetGlyphRuns(line);
        CGPoint origin = lineOrigins[i];
        for (int i = 0; i <CFArrayGetCount(runs);i++) {
            CTRunRef run = CFArrayGetValueAtIndex(runs, i);
            CFRange range = CTRunGetStringRange(run);
            if (range.location > location || range.location + range.length<= location) {
                continue;
            }
            CGFloat ascent ;
            CGFloat descent ;

            CGFloat width = (CGFloat)CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &ascent, &descent, nil);
            CGFloat offsetX = CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, nil);
            CGRect viewBounds = CGRectMake(origin.x + offsetX, origin.y - descent, width, ascent + descent);
            [pageView.views addObject:@{
                                         @"switch" :viewDic[@"switch"],
                                         @"switchFrame": [NSValue valueWithCGRect:viewBounds]
                                         }];
            self.viewIndex += 1;
            if (self.viewIndex < arr.count) {
                viewDic = arr[_viewIndex];
                location = [viewDic[@"location"] intValue];
            }
        }

    }

}



@end
