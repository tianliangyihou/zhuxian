//
//  ViewController.m
//  图文混排
//
//  Created by dengweihao on 2018/2/1.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import "ViewController.h"
#import "LBAnalysiser.h"
#import "LBView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"jianshu.txt" ofType:nil];
    NSString *text = [[NSString alloc]initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    LBAnalysiser *ay = [[LBAnalysiser alloc]init];
    [ay lb_analysisWithText:text];
    [(LBView *)self.view buildFramesWithAttr:ay.attrString andImages:ay.arr andView:ay.views];
    UIView *caole = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 200, 24)];
    caole.backgroundColor = [UIColor blackColor];
    caole.alpha = 0.5;
    [self.view addSubview:caole];
}
- (BOOL)prefersStatusBarHidden {
    return YES;
}

@end
